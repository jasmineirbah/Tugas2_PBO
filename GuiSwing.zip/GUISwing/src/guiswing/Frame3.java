
package guiswing;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

public class Frame3 extends JFrame implements ActionListener{
    private JTextField txtNama, txtTelepon, txtHari;
    private JRadioButton rbA, rbB, rbC;
    private JButton btnSimpan, btnKembali;
    private JLabel label, nama, telepon, hari, jenis;
    
    Frame3() {
        //JFrame
        setTitle("Latihan Kuis Frame 3");
        setSize(480,400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(null);
        setLocationRelativeTo(null);
        setAlwaysOnTop(true);
        getContentPane().setBackground(new Color(0x123456));
        
        //JLabel
        label = new JLabel("Welcome to this page!",SwingConstants.CENTER);
        label.setFont(Frame1.titleFont);
        label.setForeground(Color.white);
        label.setBounds(0, 20, getWidth(), 30);
        
        //JLabel Nama
        nama = new JLabel("Nama Penyewa : ");
        nama.setFont(Frame1.fieldFont);
        nama.setForeground(Color.white);
        nama.setBounds(40, 70, 120, 25);
        
        //JTextField Nama
        txtNama = new JTextField();
        txtNama.setFont(Frame1.labelFont);
        txtNama.setBounds(170, 70, 250, 25);
        
        //JLabel Telepon
        telepon = new JLabel("Nomor Telepon : ");
        telepon.setFont(Frame1.fieldFont);
        telepon.setForeground(Color.white);
        telepon.setBounds(40, 110, 120, 25);
        
        //JTextField Telepon
        txtTelepon = new JTextField();
        txtTelepon.setFont(Frame1.labelFont);
        txtTelepon.setBounds(170, 110, 250, 25);
        
        //JLabel Hari
        hari = new JLabel("Jumlah Hari Sewa : ");
        hari.setFont(Frame1.fieldFont);
        hari.setForeground(Color.white);
        hari.setBounds(40, 150, 140, 25);
        
        //JTextField Hari
        txtHari = new JTextField();
        txtHari.setFont(Frame1.labelFont);
        txtHari.setBounds(170, 150, 250, 25);
        
        //JLabel jenis motor
        jenis = new JLabel("Pilih jenis kendaraan : ");
        jenis.setFont(Frame1.fieldFont);
        jenis.setForeground(Color.white);
        jenis.setBounds(40, 190, 200, 25);
        
        //JRadioButton Kendaraan A
        rbA = new JRadioButton("Kendaraan A per hari- Rp 225.000");
        rbA.setBounds(60, 220, 300, 25);
        rbA.setFont(Frame1.labelFont);
        rbA.addActionListener(this);
        
        //JRadioButton Kendaraan B
        rbB = new JRadioButton("Kendaraan B per hari- Rp 325.000");
        rbB.setBounds(60, 250, 300, 25);
        rbB.setFont(Frame1.labelFont);
        rbB.addActionListener(this);
        
        //JRadioButton Kendaraan C
        rbC = new JRadioButton("Kendaraan C per hari- Rp 375.000");
        rbC.setBounds(60, 280, 300, 25);
        rbC.setFont(Frame1.labelFont);
        rbC.addActionListener(this);
        
        //JButton Kembali 
        btnKembali = new JButton("Kembali");
        btnKembali.setFont(Frame1.fieldFont);
        btnKembali.setBounds(100, 320, 130, 32);
        btnKembali.addActionListener(this); 
        
        //JButton Simpan
        btnSimpan = new JButton("Simpan");
        btnSimpan.setFont(Frame1.fieldFont);
        btnSimpan.setBounds(250, 320, 130, 32);
        btnSimpan.addActionListener(this);
        
        add(label);
        add(nama);
        add(telepon);
        add(hari);
        add(jenis);
        add(txtNama);
        add(txtHari);
        add(txtTelepon);
        add(rbA);
        add(rbB);
        add(rbC);
        add(btnSimpan);
        add(btnKembali);
        
        setVisible(true);
    }
    @Override
    public void actionPerformed(ActionEvent e){
        try{
            String namaPenyewa, teleponPenyewa;
            int hariPenyewa;
            
            if(e.getSource()==btnKembali){
                new Frame1();
                this.dispose();
            }else if(e.getSource()==btnSimpan){
                        namaPenyewa = txtNama.getText();
                        teleponPenyewa = txtTelepon.getText();
                        hariPenyewa = Integer.parseInt(txtHari.getText().trim());
                        
                        if (namaPenyewa.isEmpty() || teleponPenyewa.isEmpty() || txtHari.getText().trim().isEmpty()) {
                        JOptionPane.showMessageDialog(this, "Harap isi semua data!", "Error", JOptionPane.ERROR_MESSAGE);
                        return;
                        }
                        
                        if(hariPenyewa <= 0){
                            JOptionPane.showMessageDialog(this, "Angka harus lebih dari 0", "Error", JOptionPane.ERROR_MESSAGE);
                            return;
                        }
                       
                        if(rbA.isSelected()){
                            new Frame4(namaPenyewa, teleponPenyewa, hariPenyewa, "Kendaraan A", 225000);
                            this.dispose();
                            
                        } else if(rbB.isSelected()){
                            new Frame4(namaPenyewa, teleponPenyewa, hariPenyewa, "Kendaraan B", 325000);
                            this.dispose();
                            
                        } else if(rbC.isSelected()){
                            new Frame4(namaPenyewa, teleponPenyewa, hariPenyewa, "Kendaraan C", 375000);
                            this.dispose();
                            
                        }
                JOptionPane.showMessageDialog(this, "Berhasil", "Success", JOptionPane.INFORMATION_MESSAGE);
            } 
        }catch(Exception error){
            JOptionPane.showMessageDialog(this, error.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
