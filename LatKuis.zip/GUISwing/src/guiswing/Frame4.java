
package guiswing;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Locale;
import javax.swing.*;


public class Frame4 extends JFrame implements ActionListener{
    private JLabel label, lnama, ltelepon, lhari, ljenis, ltotalHarga;
    private JButton btnSelesai;
    private int total;
    
    Frame4(String namaPenyewa, String teleponPenyewa, int hariPenyewa, String jenisKendaraan, int harga){
        this.total = harga * hariPenyewa;
        
        //JFrame
        setTitle("Latihan Kuis Frame 4");
        setSize(480,400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(null);
        setLocationRelativeTo(null);
        setAlwaysOnTop(true);
        getContentPane().setBackground(new Color(0x123456));
        
        //JLabel
        label = new JLabel("Welcome to this page " + namaPenyewa, SwingConstants.CENTER);
        label.setFont(Frame1.titleFont);
        label.setForeground(Color.white);
        label.setBounds(30, 20, 380, 30);
        
        //JLabel Nama Penyewa 
        lnama = new JLabel("Nama : " + namaPenyewa);
        lnama.setFont(Frame1.labelFont);
        lnama.setForeground(Color.white);
        lnama.setBounds(50, 70, 300, 25);
        
        //JLabel Telepon
        ltelepon = new JLabel("Nomor Telepon : " + teleponPenyewa);
        ltelepon.setFont(Frame1.labelFont);
        ltelepon.setForeground(Color.white);
        ltelepon.setBounds(50, 100, 300, 25);
        
        //JLabel Jumlah Hari
        lhari = new JLabel("Jumlah Hari : " + hariPenyewa);
        lhari.setFont(Frame1.labelFont);
        lhari.setForeground(Color.white);
        lhari.setBounds(50, 130, 300, 25);
        
        //JLabel Jenis Kendaraan dan Harga/hari
        ljenis = new JLabel("Jenis Kendaraan : " + jenisKendaraan + "  |  Harga per hari : Rp " + formatHarga(harga));
        ljenis.setFont(Frame1.labelFont);
        ljenis.setForeground(Color.white);
        ljenis.setBounds(50, 160, 380, 25);
        
        //JLabel Total Harga
        ltotalHarga = new JLabel("Total Harga : ( Rp " + formatHarga(harga) + " x "+ hariPenyewa+ ") = Rp " + formatHarga(total));
        ltotalHarga.setFont(Frame1.labelFont);
        ltotalHarga.setForeground(Color.white);
        ltotalHarga.setBounds(50, 190, 300, 25);
        
        //btnselesai
        btnSelesai = new JButton("Selesai");
        btnSelesai.setFont(Frame1.fieldFont);
        btnSelesai.setBounds(250, 250, 130, 32); 
        btnSelesai.addActionListener(this);
       
        add(label);
        add(lnama);
        add(ltelepon);
        add(ljenis);
        add(lhari);
        add(ltotalHarga);
        add(btnSelesai);
        
        setVisible(true);
    }
    
    private String formatHarga(int n){
        String formattedNumber = String.format(Locale.US,"%,d",n).replace(",",".");
        return formattedNumber;
    }
    
    @Override
    public void actionPerformed(ActionEvent e){
            if(e.getSource()==btnSelesai){
            int confirm = JOptionPane.showConfirmDialog(this, "Apakah Anda yakin selesai?", "Confirm Logout", JOptionPane.YES_NO_OPTION);

            if(confirm==JOptionPane.YES_NO_OPTION){
                this.dispose();
                System.exit(0);
            }
        }
        
    }
}



