
package guiswing;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

public class Frame4 extends JFrame implements ActionListener{
    private JLabel label, lnama, ltelepon, lhari, ljenis, lharga, ltotalHarga;
    private JButton btnSelesai;
    
    //private String namaPenyewa; // untuk narik "namaPenyewa" dari frame2/3
    private int total;
    //private int harga;
    //private int hariPenyewa;
    
    Frame4(String namaPenyewa, String teleponPenyewa, int hariPenyewa, String jenisKendaraan, int harga){
        //this.namaPenyewa = namaPenyewa;
        this.total = harga * hariPenyewa;
        //this.harga = harga;
        //this.hariPenyewa = hariPenyewa;
        
        //JFrame
        setTitle("Latihan Kuis Frame 4");
        setSize(480,400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(null);
        setLocationRelativeTo(null);
        setAlwaysOnTop(true);
        getContentPane().setBackground(new Color(0x123456));
        
        //JLabel
        label = new JLabel("Welcome to this page " + namaPenyewa, SwingConstants.CENTER);
        label.setFont(Frame1.titleFont);
        label.setForeground(Color.white);
        label.setBounds(30, 20, 380, 30);
        
        //JLabel Nama Penyewa 
        lnama = new JLabel("Nama : " + namaPenyewa);
        lnama.setFont(Frame1.labelFont);
        lnama.setForeground(Color.white);
        lnama.setBounds(50, 70, 300, 25);
        
        //JLabel Telepon
        ltelepon = new JLabel("Nomor Telepon : " + teleponPenyewa);
        ltelepon.setFont(Frame1.labelFont);
        ltelepon.setForeground(Color.white);
        ltelepon.setBounds(50, 100, 300, 25);
        
        //JLabel Jumlah Hari
        lhari = new JLabel("Jumlah Hari : " + hariPenyewa);
        lhari.setFont(Frame1.labelFont);
        lhari.setForeground(Color.white);
        lhari.setBounds(50, 130, 300, 25);
        
        //JLabel Jenis Kendaraan dan Harga/hari
        ljenis = new JLabel("Jenis Kendaraan : " + jenisKendaraan + "Harga per hari : Rp " + harga);
        ljenis.setFont(Frame1.labelFont);
        ljenis.setForeground(Color.white);
        ljenis.setBounds(50, 160, 380, 25);
        
        //JLabel Total Harga
        ltotalHarga = new JLabel("Total Harga Sewa : " + total);
        ltotalHarga.setFont(Frame1.labelFont);
        ltotalHarga.setForeground(Color.white);
        ltotalHarga.setBounds(50, 190, 300, 25);
        
        //btnKembali = new JButton("Kembali ke frame 1");
        //btnKembali.setFont(Frame1.fieldFont);
        //btnKembali.setBounds(100, 250, 130, 32);
        //btnKembali.addActionListener(this);
        
        btnSelesai = new JButton("Selesai");
        btnSelesai.setFont(Frame1.fieldFont);
        btnSelesai.setBounds(250, 250, 130, 32); 
        btnSelesai.addActionListener(this);
       
        add(label);
        add(lnama);
        add(ltelepon);
        add(lharga);
        add(ljenis);
        add(lhari);
        add(ltotalHarga);
        //add(btnKembali);
        add(btnSelesai);
        
        setVisible(true);
    }
    @Override
    public void actionPerformed(ActionEvent e){
            //if(e.getSource()==btnKembali){
                //JOptionPane.showMessageDialog(this, "Berhasil", "Success", JOptionPane.INFORMATION_MESSAGE);
                //new Frame1(); //pindah ke hal Frame1
                //this.dispose(); //menutup hal Frame4  
            //} else 
            if(e.getSource()==btnSelesai){
            int confirm = JOptionPane.showConfirmDialog(this, "Apakah Anda yakin selesai?", "Confirm Logout", JOptionPane.YES_NO_OPTION);

            if(confirm==JOptionPane.YES_NO_OPTION){
                this.dispose();
            }
        }
        
    }
}



