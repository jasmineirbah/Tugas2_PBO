
package guiswing;

import java.awt.*;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

public class Frame1 extends JFrame implements ActionListener{
    //Font global
    public static Font titleFont = new Font("Times New Roman", Font.BOLD, 24);
    public static Font labelFont = new Font("Times New Roman", Font.PLAIN, 14);
    public static Font fieldFont = new Font("Times New Roman", Font.BOLD, 14);
    
    private JButton btnMotor, btnMobil;
    private JLabel label;
    
    Frame1(){ //Constructor
        //JFrame
        setTitle("Latihan Kuis Frame 1");
        setSize(480,400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
        setLayout(null);
        setLocationRelativeTo(null);
        setAlwaysOnTop(true);
        getContentPane().setBackground(new Color(0x123456));
        
        //JLabel
        label = new JLabel("Pilihan Kendaraan");
        //label.setHorizontalTextPosition(JLabel.CENTER);
        //label.setVerticalTextPosition(JLabel.TOP);
        label.setFont(titleFont);
        label.setBounds(135, 40, getWidth(), 30);
        label.setForeground(Color.white);
        //label.setBackground(Color.black);
        //label.setOpaque(true);
        
        //JButton 
        btnMotor = new JButton("Motor");
        btnMotor.setFont(fieldFont);
        btnMotor.setBounds(70, 220, 150, 32);
        btnMotor.addActionListener(this); //"this" = class Frame1
       
        btnMobil = new JButton("Mobil");
        btnMobil.setFont(fieldFont);
        btnMobil.setBounds(240, 220, 150, 32);
        btnMobil.addActionListener(this); 
        
        add(btnMotor);
        add(btnMobil);
        add(label);
    }
    @Override
    public void actionPerformed(ActionEvent e){
        try{
            if(e.getSource()==btnMotor){
                JOptionPane.showMessageDialog(this, "Berhasil", "Success", JOptionPane.INFORMATION_MESSAGE);
                new Frame2(); //pindah ke hal Frame2
                this.dispose(); //menutup hal Frame1  
            } else if(e.getSource()==btnMobil){
                JOptionPane.showMessageDialog(this, "Berhasil", "Success", JOptionPane.INFORMATION_MESSAGE);
                new Frame3(); //pindah ke hal Frame3
                this.dispose(); //menutup hal Frame1
            }
        }catch(Exception error){
            JOptionPane.showMessageDialog(this, error.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
