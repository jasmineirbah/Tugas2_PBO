
package guiswing;

public class Main {

    public static void main(String[] args) {
        new Frame1();
    }
    
}
